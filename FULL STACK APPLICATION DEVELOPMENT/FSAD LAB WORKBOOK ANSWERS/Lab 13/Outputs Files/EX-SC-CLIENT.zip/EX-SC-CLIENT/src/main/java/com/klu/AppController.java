package com.klu;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AppController {

    @Value("${msg:Not Connected to Server}")
    String msg;

    @GetMapping("/clientfun")
    public String fun1() {
        return msg;
    }
}