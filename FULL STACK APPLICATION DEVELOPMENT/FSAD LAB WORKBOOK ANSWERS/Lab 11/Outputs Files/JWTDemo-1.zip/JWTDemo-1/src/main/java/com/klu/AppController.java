package com.klu;

import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController
public class AppController {

    private final JWTManager jwt;

    public AppController(JWTManager jwt) {
        this.jwt = jwt;
    }

    @GetMapping("/login")
    public String login(@RequestParam String username) {
        return jwt.generateToken(username);
    }

    @GetMapping("/validate")
    public Map<String, String> validate(@RequestParam String token) {
        return jwt.validateToken(token);
    }
}
