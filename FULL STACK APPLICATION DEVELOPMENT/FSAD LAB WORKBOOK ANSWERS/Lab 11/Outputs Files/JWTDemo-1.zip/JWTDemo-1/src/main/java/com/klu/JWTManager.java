package com.klu;

import java.security.MessageDigest;
import java.util.*;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;
import org.springframework.stereotype.Service;

import java.util.Base64;

@Service
public class JWTManager {

    private final SecretKey key = Keys.hmacShaKeyFor("awdsiuchuidcidvijsuidjuiwehdcdhuichecefuerhfui".getBytes());

    public String generateToken(String username) {
        return Jwts.builder()
                .setClaims(Map.of("username", username))
                .setSubject(username)
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + 86400000))
                .signWith(key)
                .compact();
    }

    public Map<String, String> validateToken(String token) {
        try {
            Claims claims = Jwts.parserBuilder().setSigningKey(key).build().parseClaimsJws(token).getBody();
            if (claims.getExpiration().before(new Date()))
                return Map.of("code", "404", "message", "Invalid Token");
            return Map.of("code", "200", "message", claims.get("username", String.class));
        } catch (Exception e) {
            return Map.of("code", "404", "message", "Invalid Token");
        }
    }

    public String decryptData(String encryptedData) {
        try {
            byte[] keyBytes = MessageDigest.getInstance("SHA-256").digest("THANOS".getBytes());
            SecretKey key1 = new SecretKeySpec(keyBytes, 0, 16, "AES");
            Cipher cipher = Cipher.getInstance("AES");
            cipher.init(Cipher.DECRYPT_MODE, key1);
            return new String(cipher.doFinal(Base64.getDecoder().decode(encryptedData)));
        } catch (Exception e) {
            return e.getMessage();
        }
    }
}
