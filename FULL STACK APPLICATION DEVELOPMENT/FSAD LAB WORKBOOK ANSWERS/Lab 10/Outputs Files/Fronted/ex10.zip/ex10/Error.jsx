import React from "react";

export default function Error() {
    return (
        <div>
            <center>
                <div className='signin-box'>
                    This is an Error Page. You are not authorized to access other pages.
                </div>
            </center>
        </div>
    );
}
