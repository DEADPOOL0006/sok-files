import React from "react";
import './style.css';
import axios from 'axios';


export default function Signup() {

function insertUser(){

    var un = document.getElementsByName("un")[0].value;
    var pw = document.getElementsByName("pw")[0].value;
    var role = document.getElementsByName("role")[0].value;

axios.post("http://localhost:8081/user", {

    "un": un,
    "pw": pw,
    "role": role
}).then((res)=>{
    alert(res.data)

})
}

    return (
        <div>
            <center>
            <div className='signin-box'>
                <table>
                    <tbody>
                        <tr>
                            <td colSpan={2}>Signup Page</td>
                        </tr>
                        <tr>
                            <td>Username:</td>
                            <td><input type="text" name="un"class="form-control" /></td>
                        </tr>
                        <tr>
                            <td>Password:</td>
                            <td><input type="password" name="pw" class="form-control"  /></td>
                        </tr>
                        <tr>
                            <td>Role:</td>
                            <td>
                                <select class="form-select" name="role">
                                    <option value={1}>Admin</option>
                                    <option value={2}>User</option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td colSpan={2}><button onClick={insertUser}> Signup </button></td>
                        </tr>
                    </tbody>
                </table>
            </div>
            </center>
        </div>
    );
}
