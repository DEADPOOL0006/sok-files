import React from "react";

export default function Home() {
    return (
        <div>
            <center>
                <div className='signin-box'>
                    This is a Home Page
                </div>
            </center>
        </div>
    );
}
