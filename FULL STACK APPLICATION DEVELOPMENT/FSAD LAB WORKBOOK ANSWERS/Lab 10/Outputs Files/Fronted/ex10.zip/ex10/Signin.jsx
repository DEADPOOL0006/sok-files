import React from "react";
import './style.css';
import axios from 'axios';

export default function Signin({store}) {

function checkUser() {

    var un = document.getElementsByName("un")[0].value;
    var pw = document.getElementsByName("pw")[0].value;

axios.post("http://localhost:8081/check", {

    "un": un,
    "pw": pw,
}).then((res)=>{
    alert(res.data)
    if(res.data !== "0"){
sessionStorage.setItem("un" ,un)
sessionStorage.setItem("role" ,res.data)
store.dispatch({ "type": "page", "data": "Home" })
    }
})
}
    return (
        <div>
            <center>
                <div className='signin-box'>
                    <table>
                        <tbody>
                            <tr>
                                <td colSpan={2}>Signin Page</td>
                            </tr>
                            <tr>
                                <td>Username:</td>
                                <td><input type="text" name="un" className="form-control" /></td>
                            </tr>
                            <tr>
                                <td>Password:</td>
                                <td><input type="password" name="pw" className="form-control" /></td>
                            </tr>
                            <tr>
                                <td colSpan={2}><button onClick={checkUser}>Login</button></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </center>
        </div>
    );
}
