import React from "react";

export default function Admin() {
    return (
        <div>
            <center>
                <div className='signin-box'>
                    This is an Admin Page
                </div>
            </center>
        </div>
    );
}
