package com.klu;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin
public class Appcontroller {

    @Autowired
    Service s;

    // http://localhost:8081/product
    @PostMapping("/product")
    public String insertProduct(@RequestBody Product product) {
        return s.insertData(product);
    }
    
    // http://localhost:8081/product
    @PutMapping("/product")
    public String updateProduct(@RequestBody Product product) {
        return s.updateData(product);
    }

    // http://localhost:8081/product/1
    @DeleteMapping("/product/{id}")
    public String deleteProduct(@PathVariable int id) {
        return s.deleteData(id);
    }

    @GetMapping("/product")
    public List<Product> retrieveProduct() {
        return s.retrieveData();
    }
    
    // http://localhost:8081/user
    @PostMapping("/user")
    public String insertUser(@RequestBody User user) {
        return s.insertUser(user);
    }
    
    // http://localhost:8081/check
    @PostMapping("/check")
    public String retrieveUser(@RequestBody User user) {
        return s.checkUser(user);
    }
}