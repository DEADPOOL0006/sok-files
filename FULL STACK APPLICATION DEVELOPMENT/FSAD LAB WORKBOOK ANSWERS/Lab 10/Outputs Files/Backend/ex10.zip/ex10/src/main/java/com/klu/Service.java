package com.klu;

import org.springframework.beans.factory.annotation.Autowired;
import java.util.List;

@org.springframework.stereotype.Service
public class Service {

    @Autowired
    private ProductRepo repo1;
    
    @Autowired
    UserRepo repo2;
    
    public String insertUser (User user) {
    	
    	repo2.save(user);
    	return "Success";
    }
    
    public String checkUser(User user) {
    	
    	User userRetrieved = repo2.findByUn(user.getUn());
    if( userRetrieved != null) {
    	if(userRetrieved.getPw().equals(user.getPw())) {
    return userRetrieved.getRole();
    	}
    	
    	else {
    		return "0";
    	}
    }
    
    else {
    	return "0";
    }
    }
    
    public String insertData(Product product) {
        repo1.save(product);
        return "Inserted Successfully";
    }

    public String updateData(Product product) {
        if (repo1.findById(product.getId()) != null)
        	repo1.delete(product);
            repo1.save(product);
            return "Updated Successfully";
        } 

    public String deleteData(int id) {
        repo1.delete (repo1.findById(id) .get()); 
            repo1.deleteById(id);
            return "Deleted Successfully";
    }

    public List<Product> retrieveData() {
        return repo1.findAll();
    }
}
