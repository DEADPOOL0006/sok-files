import edu.princeton.cs.algs4.StdIn;
import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.StdRandom;

public class RandomWord {
    public static void main(String[] args) {
        int Brahmendra1 = 0;
        String Brahmendra2 = "";

        while (!StdIn.isEmpty()) {
            String Brahmendra3 = StdIn.readString();
            boolean Brahmendra4 = StdRandom.bernoulli(1 / (Brahmendra1 + 1.0));
            if (Brahmendra4) {
                Brahmendra2 = Brahmendra3;
            }
            Brahmendra1++;
        }
        StdOut.println(Brahmendra2);
    }
}
