public class HelloGoodbye {
    public static void main(String[] args) {
        String Brahmendra1 = args[0];
        String Brahmendra2 = args[1];

        System.out.println("Hello " + Brahmendra1 + " and " + Brahmendra2 + ".");
        System.out.println("Goodbye " + Brahmendra2 + " and " + Brahmendra1 + ".");
    }
}
