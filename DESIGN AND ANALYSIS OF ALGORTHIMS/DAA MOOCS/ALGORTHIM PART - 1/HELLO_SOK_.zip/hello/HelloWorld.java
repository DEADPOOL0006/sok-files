public class HelloWorld {
    public static void main(String[] args) {
        String Brahmendra1 = "Hello";
        String Brahmendra2 = "World";
        String Brahmendra3 = Brahmendra1 + ", " + Brahmendra2;

        System.out.println(Brahmendra3);
    }
}
